﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerCRUD.Models
{
    public class ApplicationDbContextcs:DbContext
    {
        public ApplicationDbContextcs(DbContextOptions<ApplicationDbContextcs> options) : base(options) { }

        public DbSet<CustomerModel> Customers { get; set; }

    }
}
