﻿using CustomerCRUD.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerCRUD.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ApplicationDbContextcs dbContext;
        private IHostingEnvironment Environment;

        public CustomerController(ApplicationDbContextcs dbContextcs , IHostingEnvironment environment)
        {
            dbContext = dbContextcs;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var cust = dbContext.Customers.ToList();
            return View(cust);

        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
  
        public IActionResult Create(CustomerModel cust)
        {
            var files = Request.Form.Files;
            string dbPath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbPath = "images/" + files[0].FileName;

                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            cust.Image = dbPath;

            dbContext.Customers.Add(cust);
            dbContext.SaveChanges();
            return RedirectToAction("Index");

        }
        public IActionResult Edit( int id)
        {
            var cust = dbContext.Customers.SingleOrDefault(e=>e.Id==id);
            return View(cust);
        }
        [HttpPost]
       
        public IActionResult Edit(CustomerModel cust)
        {
            var files = Request.Form.Files;
            string dbPath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbPath = "images/" + files[0].FileName;

                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            cust.Image = dbPath;


            dbContext.Customers.Update(cust);
            dbContext.SaveChanges();
            return RedirectToAction("Index");

        }
        public IActionResult Delete(int id)
        {
            var cust = dbContext.Customers.SingleOrDefault (e => e.Id == id);
            if (cust!=null)
            {
                dbContext.Customers.Remove(cust);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else { 
            return RedirectToAction ("Index");
                 }
        }
        public IActionResult Detail(int id)
        {
            var cust = dbContext.Customers.Where(e => e.Id == id).FirstOrDefault();
            return View(cust);
        }
    }
}
